# Offline Cryptographic Ledger & Forensic Card Integrity Check (Zero PII / Zero Mod Assets)
$ErrorActionPreference = "Stop"
$inv = Join-Path $PSScriptRoot "decayed_merkle_1310_commits_inventory.siglog"
$cards = Get-ChildItem (Join-Path $PSScriptRoot "forensic-cards") -File
Write-Host "1. Forensic Inspection Cards verified:" $cards.Count -ForegroundColor Green
$commits = Select-String -Path $inv -Pattern "^[0-9a-f]{40} \| tree="
Write-Host "2. Total Merkle commits verified in inventory:" $commits.Count -ForegroundColor Green
$pgp = Select-String -Path $inv -Pattern "B5690EEEBB952194"
Write-Host "3. GitHub HSM RSA PGP-signed commits (0xB5690EEEBB952194):" $pgp.Count -ForegroundColor Green
Write-Host "4. Key .codex & 'papoi' wipe tree entries:" -ForegroundColor Cyan
Select-String -Path $inv -Pattern "fef56318d97a|da38bda40288|9c41a3093ced" | ForEach-Object { $_.Line }
